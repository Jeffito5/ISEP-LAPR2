# Glossary

| **_TEA_** (EN)  | **_TEA_** (PT) | **_Description_** (EN)                                           |                                       
|:------------------------|:-----------------|:--------------------------------------------|
| **Administrator** | **Administrador** | User that can add categories, test parameters, etc... |
| **Asymptotic Behaviour** | **Comportamento Assimptótico** | How a function (or algorithm) behaves near a limit. |
| **Barcode** | **Código de Barras** | Code that identifies a particular lab sample.|
| **Benchmark Algorithm** | **Algoritmo de Referência** | Algorithm used to test the efficiency of another, by comparison.|
| **Brute Force Algorithm** | **Algoritmo de Força Bruta** |  A method of problem solving in which every possibility is examined and the best one (or a best one) is chosen.|
| **Category** | **Categoria** | description |
| **Chemical Laboratory** | **Laboratório Químico** | description |
| **Client** | **Cliente** | Person requesting a clinical analysis test.|
| **Clinical Analisys Laboratory** | **...** | Laboratory where tests are carried out on clinical specimens (samples) to obtain information about the health of a patient in aid in diagnosis, treatment, and prevention of disease.|
| **Clinical Chemistry Technologist** | **...** | Receives the samples in the headquarters and performs the chemical analysis, recording the results in the software application.|
| **Configuration File** | **...** | A configuration file, often shortened to config file, defines the parameters, options, settings and preferences applied to operating systems (OSes), infrastructure devices and applications in an IT context.|
| **Courier** | **Transportador** | Transports the samples between the medical lab where the sample was collected and the headquarter where the analysis is done.|
| **Covid-19** | **...** | Coronavirus disease 2019 (COVID-19) is a contagious disease caused by severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2).|
| **Email** | **Email** | Method of exchanging messages between people using electronic devices|
| **External API** | **...** | External Application Programming Interface that has been designed to be easily accessible by the wider population, as well as web developers.|
| **External Module** | **...** |  Does an automatic validation using test reference values.|
| **GUI** | **...** | Stands for Graphical User Interface. It is a system of interactive visual components for computer software, allowing the user to interact with the software.|
| **Hemogram** | **Hemograma** | Group of tests performed on a blood sample.|
| **Internal Code** | **...** | Code associated with each test for internal lab purposes.|
| **Laboratory Coordinator** | **...** | Person that validates the results, diagnosis and reports.|
| **Lab order** | **...** | Request of clinical analysis test prescribed by a doctor.|
| **Many Labs** | **...** | Company that operates in the English market, with headwuarters in London, that has a network of clinical analysis laboratories in England|
| **Linear Regression Algorithm** | **...** | Linear Regression is a supervised machine learning algorithm where the predicted output is continuous and has a constant slope.|
| **MLT** | **MLT** | Medical Lab Technician. End users’s role, who collects the samples and records them in the system.|
| **Network** | **Rede** | A group of interconnected people or things (in our case, laboratories)|
| **NHS** | **...** | Stands for National Health Service. It is a public-health service under government administration.|
| **NHS code** | **...** | Code associated with each test for NHS purposes.|
| **Object Serialization** | **...** | TBD|
| **Ordering Algorithm** | **...** | Set of instructions that take an array or list as an input and arrange the items into a particular order.|
| **Receptionist** | **Recepcionista** | Person that will receive the client’s request and register it on the app.|
| **Sample** | **Amostra** | Matter of a medical patient's tissue, fluid, or other material derived from the patient, used for laboratory analysis to assist differential diagnosis or staging of a disease process.|
| **Specialist Doctor** | **Doutor Especialista** | Doctor that analyses the results of the chemical analyses, makes a diagnostic based on the results and writes a report.|
| **SMS** | **SMS** | Short Message Service - commonly known as texting.|
| **SVG** | **SVG** | Standard graphics file type used for rendering two-dimensional images on the internet.|
| **Test** | **Exame** | A medical procedure that involves testing a sample of blood, urine, or other substance from the body. |
| **Test Parameter** | **Parâmetro de teste** | description |
| **TIN** | **TIN/NIF** | Tax Identification Number. It is an identification number used by the Internal Revenue Service (IRS) in the administration of tax laws.|








