# Domain Model Associations

| **_Concept A_**   | **_Association_**  | **_Concept B_**                                            |                                       
|:------------------------|:-----------------|:--------------------------------------------|
| **Company** | owns | ClinicalAnalysisLaboratory |
|  |  | ChemicalLaboratory |
|  | performs | Test |
|  | conducts | TestType |
| **ChemicalLaboratory** | performs | Analysis |
| **Test** | requested by | Client |
|  | is of | TestType |
|  | registered by | Receptionist |
|  | performed by | MedicalLabTechnician |
| **Sample** | collected by | MedicalLabTechnician |
|  | is contained in | Test |
|  | collected at | ClinicalAnalysisLaboratory |
| **Analysis** | performed by | ClinicalChemstryTechnologist |
|  | performed at | ChemicalLaboratory |
|  | used for(?) | AnalysisResult |
| **AnalysisResult** | validated by | TestReference |
|  |  | SpecialistDoctor |
|  |  | LaboratoryCoordinator |
|  | used for | Diagnosis |
| **Diagnosis** | contained in | Report |
|  | done by | SpecialistDoctor |
|  | checked by | LaboratoryCoordinator |
| **Parameter** | presented under | Category |
|  | requested by | Test |
| **Category** | created by | Administrator |
| **Receptionist** | is part of | Staff |
|  | registers | Client |
|  | registers | Test |
| **MedicalLabTechnician** | is part of | Staff |
|  | collects and registers | Sample |
| **ClinicalChemistryTechnologist** | is part of | Staff |
|  | performs | Analysis |
|  | records | AnalysisResult |
| **SpecialistDoctor** | is part of | Staff |
|  | makes | Diagnosis |
|  | writes | Report |
| **LaboratoryCoordinator** | is part of | Staff |
|  | validates | AnalysisResult |
|  |  | Diagnosis |
| **Administrator** | registers | Staff |
|  | creates | Category |
|  |  | TestType |
|  |  | Parameter |
| **Client** | registered by | Receptionist |
|  | requests | Test |
|  | uses | LabOrder |
| **LabOrder** | prescribed by | Doctor |
| **CovidReport** | uses | AnalysisResult |







